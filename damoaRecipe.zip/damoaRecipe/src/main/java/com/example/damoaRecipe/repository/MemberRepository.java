// MemberRepository.java

package com.example.damoaRecipe.repository;

import com.example.damoaRecipe.entity.Member;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface MemberRepository extends JpaRepository<Member, Long> { // SiteUser PK 타입 : Long
    Optional<Member> findByMemberName(String memberName); // 사용자 조회 기능
}