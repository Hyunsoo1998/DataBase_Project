
package com.example.damoaRecipe.entity;

public enum MemberStatus {
    ACTIVE,
    INACTIVE,
    PENDING_ACTIVATION,
    SUSPENDED,
    DELETED
}