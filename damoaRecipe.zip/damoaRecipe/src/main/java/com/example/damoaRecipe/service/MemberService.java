// MemberService.java

package com.example.damoaRecipe.service;

import com.example.damoaRecipe.exception.DataNotFoundException;
import com.example.damoaRecipe.repository.MemberRepository;
import com.example.damoaRecipe.entity.Member;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Optional;

@RequiredArgsConstructor
@Service
public class MemberService {
    private final MemberRepository memberRepository;

    public Member create(String memberPw, String memberName, String memberEmail, String memberImage) {
        Member member = new Member(memberPw, memberName, memberEmail, memberImage);
//        member.setMemberPw(memberPw);
//        member.setMemberName(memberName);
//        member.setMemberEmail(memberEmail);
//        member.setMemberImage(memberImage);
        return memberRepository.save(member);
    }

    public Member getMember(String memberName) {
        Optional<Member> member = this.memberRepository.findByMemberName(memberName);
        if (member.isPresent()) {
            return member.get();
        }
        else {
            throw new DataNotFoundException("member not found");
        }
    }
}
