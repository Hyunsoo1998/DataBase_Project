// MemberController.java

package com.example.damoaRecipe.controller;

import com.example.damoaRecipe.form.MemberCreateForm;
import com.example.damoaRecipe.repository.MemberRepository;
import com.example.damoaRecipe.service.MemberService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@RequiredArgsConstructor
@Controller
@RequestMapping("/member")
public class MemberController {
    private final MemberService memberService;

    @GetMapping("/signup") // 회원가입을 위한 템플릿 렌더링
    public String signup(MemberCreateForm memberCreateForm) {
        return "signup_form";
    }

    @PostMapping("/signup") // 회원가입 진행
    public String signup(@Valid MemberCreateForm memberCreateForm, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) { // bindingResult : 검증 오류 보관 객체
            return "signup_form";
        }

//        if (!memberCreateForm.getPassword1().equals(memberCreateForm.getPassword2())) { // 값이 일치하지 않을 경우 오류 발생
//            bindingResult.rejectValue("password2", "passwordInCorrect", "2개의 패스워드가 일치하지 않습니다."); // (필드명, 오류코드, 에러메시지)
//            return "signup_form";
//        }

        try {
            memberService.create(memberCreateForm.getMemberPw(), memberCreateForm.getMemberName(), memberCreateForm.getMemberEmail(), memberCreateForm.getMemberImage());
        } catch(DataIntegrityViolationException e) { // 사용자 ID 또는 이메일 주소가 동일할 경우 에러
            e.printStackTrace();
            bindingResult.reject("signupFailed", "이미 등록된 사용자입니다.");
            return "signup_form";
        } catch(Exception e) {
            e.printStackTrace();
            bindingResult.reject("signupFailed", e.getMessage());
            return "signup_form";
        }
        return "redirect:/"; // redirect 후에 적힌 주소로 URL 요청 다시 함
    }

    @GetMapping("/login") // 스프링 시큐리티가 대신 처리하므로 구현 X
    public String login() {
        return "login_form";
    }

    @GetMapping("/main")
    public String main() {
        return "main";
    }
}
