// MemberCreateForm.java

package com.example.damoaRecipe.form;

import com.example.damoaRecipe.entity.MemberStatus;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.time.LocalDateTime;

@Getter
@Setter
@ToString
public class MemberCreateForm {
    private Long memberId;
    private String memberPw;
    private String memberName;
    private String memberEmail;
    private String memberImage;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private MemberStatus memberStatus;
    // 추가적으로 필요한 필드가 있다면 추가할 수 있습니다.

    // 기본 생성자
    public MemberCreateForm() {
    }

    // 매개변수를 받는 생성자
    public MemberCreateForm(Long memberId, String memberPw, String memberName, String memberEmail, String memberImage /* , LocalDateTime updatedAt*/) {
        this.memberId = memberId;
        this.memberPw = memberPw;
        this.memberName = memberName;
        this.memberEmail = memberEmail;
        this.memberImage = memberImage;
        //this.updatedAt = updatedAt;
    }
}