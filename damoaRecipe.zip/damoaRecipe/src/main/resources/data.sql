INSERT INTO Categories ("한식")  values ('category 1');
INSERT INTO Categories ("중식")  values ('category 2');
INSERT INTO Categories ("일식")  values ('category 3');

INSERT INTO recipe(recipe_Name, recipe_Content) VALUES('가가가','11111');
INSERT INTO recipe(recipe_Name, recipe_Content) VALUES('나ㅏ나','2222');
INSERT INTO recipe(recipe_Name, recipe_Content) VALUES('다다다','3333');
INSERT INTO recipe(recipe_Name, recipe_Content) VALUES('gndkdb','tktktk');
INSERT INTO recipe(recipe_Name, recipe_Content) VALUES('alal','e;e');
INSERT INTO recipe(recipe_Name, recipe_Content) VALUES('le','we');


INSERT INTO review(review_author_id, review_content,recipe_id) VALUES('park','rnr',4);
INSERT INTO review(review_author_id, review_content,recipe_id) VALUES('kin','s',4);
INSERT INTO review(review_author_id, review_content,recipe_id) VALUES('a','w',4);
INSERT INTO review(review_author_id, review_content,recipe_id) VALUES('park','rnr',5);